# Copyright (c) 2026 Forty5 Park. All Rights Reserved.
# Proprietary and confidential. See LICENSE.
"""Sanity-check script: load all four Yardi parquets and print summary stats.

Run from anywhere:
    python vignette/01_geospatial_expansion/notebooks/00_load_data.py

If this prints four shape lines and no errors, your environment is ready.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

DATA = Path(__file__).resolve().parent.parent / "data"


def main() -> int:
    feeds = {
        "property-enriched": "042026-property-enriched-12060.parquet",
        "unit-mix-enriched": "042026-unit-mix-enriched-12060.parquet",
        "rent (target)": "042026-rent-12060.parquet",
        "hist-rent (panel)": "042026-hist-rent-12060-12060.parquet",
        "yardi-sales": "yardi_sales_atl.parquet",
    }

    frames: dict[str, pd.DataFrame] = {}
    for name, filename in feeds.items():
        path = DATA / filename
        if not path.exists():
            print(f"  {name:<22s}: missing ({path})")
            continue
        frames[name] = pd.read_parquet(path)

    print("=" * 60)
    print("FEED                    ROWS  ×  COLS")
    print("-" * 60)
    for name, df in frames.items():
        print(f"  {name:<22s}{df.shape[0]:>8,d}  ×  {df.shape[1]:>3d}")
    print()

    # Geography overview
    if "property-enriched" in frames:
        prop = frames["property-enriched"]
        print("Top 10 submarkets by property count:")
        if "sub_market" in prop.columns:
            print(prop["sub_market"].value_counts().head(10).to_string())
        print()
        print(f"Latitude range:  {prop['latitude'].min():.4f}  to  {prop['latitude'].max():.4f}")
        print(f"Longitude range: {prop['longitude'].min():.4f}  to  {prop['longitude'].max():.4f}")
        print(f"Year built range: {prop['year_built'].min():.0f}  to  {prop['year_built'].max():.0f}")
        print()

    # Target distribution
    if "rent (target)" in frames:
        rent = frames["rent (target)"]
        print("Target rent distribution (training snapshot):")
        print(rent["rent"].describe().to_string())
        print()

    # Historical panel coverage
    if "hist-rent (panel)" in frames:
        hist = frames["hist-rent (panel)"]
        hist["period"] = pd.to_datetime(hist["period"])
        print(f"Hist-rent panel: {hist['period'].min().date()}  to  {hist['period'].max().date()}")
        print(f"  unique properties:        {hist['property_id'].nunique():,d}")
        print(f"  unique (prop, unit_type): {hist.groupby(['property_id', 'unit_type']).ngroups:,d}")
        print(f"  total observations:       {len(hist):,d}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
