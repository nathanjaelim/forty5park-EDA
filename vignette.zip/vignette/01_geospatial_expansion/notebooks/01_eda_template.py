# Copyright (c) 2026 Forty5 Park. All Rights Reserved.
# Proprietary and confidential. See LICENSE.
"""EDA template — fill in the blanks. Convert to a Jupyter notebook if you like.

Each section corresponds to a day in Phase 1 of the project brief.
Replace each `TODO:` block with your analysis. The goal is to produce a
notebook YOU would be willing to walk a teammate through.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

DATA = Path(__file__).resolve().parent.parent / "data"

property_df = pd.read_parquet(DATA / "042026-property-enriched-12060.parquet")
unit_mix_df = pd.read_parquet(DATA / "042026-unit-mix-enriched-12060.parquet")
rent_df = pd.read_parquet(DATA / "042026-rent-12060.parquet")
hist_df = pd.read_parquet(DATA / "042026-hist-rent-12060-12060.parquet")
hist_df["period"] = pd.to_datetime(hist_df["period"])


# ---------------------------------------------------------------------------
# Day 1-2: Schema, nullness, cardinality
# ---------------------------------------------------------------------------

# TODO: For each of the four dataframes, print:
#   - df.shape
#   - df.dtypes.value_counts()
#   - top 10 columns by null fraction
#   - cardinality of every object-typed column (df.nunique())


# ---------------------------------------------------------------------------
# Day 3: Target — rent distribution
# ---------------------------------------------------------------------------

# TODO: Plot the distribution of rent_df['rent'] (histogram + KDE).
# TODO: Plot the distribution of np.log1p(rent_df['rent']). What changes?
# TODO: Join rent_df to unit_mix_df on (property_id, unit_type) to attach
#       living_area_square_feet. Compute rent / sqft. Plot that distribution.
# TODO: Group rent by unit_type and describe each group. Which unit type
#       has the highest median rent? The widest spread?
# TODO: Box-plot rent by sub_market (you'll need to join through property-enriched).
#       Sort submarkets by median rent. Which one is on top? On the bottom?


# ---------------------------------------------------------------------------
# Day 4: Geography
# ---------------------------------------------------------------------------

# TODO: Scatter-plot (longitude, latitude) of every property. Sanity-check
#       that all points are inside the Atlanta MSA.
# TODO: Color the scatter by mean rent per property. What patterns do you see?
# TODO: Pick one reference coordinate (your choice — maybe downtown Atlanta
#       at (-84.388, 33.749)). Compute Haversine distance from every property.
#       Plot rent vs distance. Is there a gradient?
# TODO: Read vignette/01_geospatial_expansion/data/atlanta_landmarks.json.
#       For each landmark, compute distance to every property. WRITE DOWN
#       YOUR TOP-3 GUESS for which landmark's distance most strongly predicts
#       rent BEFORE you compute. Then compute and compare.


# ---------------------------------------------------------------------------
# Day 5: Property attributes
# ---------------------------------------------------------------------------

# TODO: Distribution of year_built. Are there gaps? When was the Atlanta MFR boom?
# TODO: Box-plot rent by decade of year_built. What's the vintage premium?
# TODO: For each amenity flag in property_df (has_*, is_*), compute the mean
#       rent for properties WITH vs WITHOUT the amenity. Which amenities are
#       most associated with rent premiums? Are you confident the relationship
#       is causal, or could it be confounded with property quality?


# ---------------------------------------------------------------------------
# Day 6: The historical rent panel
# ---------------------------------------------------------------------------

# TODO: What's the date range of hist_df['period']? How many distinct months?
# TODO: For 5 random property_ids, plot rent over time for one unit_type each.
#       Comment on what you see.
# TODO: Compute Pearson correlation between rent[t] and rent[t-1] for one
#       (property, unit_type). Then for rent[t] and rent[t-12]. What does
#       the comparison tell you?
# TODO: Plot the MSA-wide median rent over time. Are there structural breaks?
# TODO: THE BIG ONE — look at the very last `period` in hist_df. Compare it
#       to the `period` value in rent_df. What do you notice? What does that
#       imply for using hist data as "lag features"?


# ---------------------------------------------------------------------------
# Bonus — your own questions
# ---------------------------------------------------------------------------

# TODO: What questions came up while you were exploring? Write them here.
#       The team will want to know what you wondered about that isn't covered above.
