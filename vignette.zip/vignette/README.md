# Vignettes — onboarding projects

> Hands-on projects that ramp a new team member into ownership of a Forty5 Park ML system.

Each subfolder is a self-contained mini-project: a written brief, a slice of the relevant data, and a roadmap from "first day" to "owning the model in production." Vignettes are deliberately framed as **investigations**, not tutorials — they tell you the destination and give you the data, but expect you to develop the intuition yourself.

| # | Project | Owner pathway |
|---|---|---|
| 01 | [Geospatial Expansion](01_geospatial_expansion/) | Yardi data fluency → new geo features → multi-MSA generalization → AVM ownership |
